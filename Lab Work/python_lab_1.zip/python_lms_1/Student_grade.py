# Function to calculate grade based on marks
def calculate_grade(marks):
    if marks >= 90:
        return "A"
    elif marks >= 75:
        return "B"
    elif marks >= 50:
        return "C"
    else:
        return "Fail"
for i in range(5):
    # Take marks input from user
    marks = int(input(f"Enter marks for student {i+1}: "))
    if 0 <= marks <= 100:
        # Call function to calculate grade
        grade = calculate_grade(marks)
        # Display grade
        print("Grade:", grade)
    else:
        # Print error if invalid input
        print("Invalid marks")