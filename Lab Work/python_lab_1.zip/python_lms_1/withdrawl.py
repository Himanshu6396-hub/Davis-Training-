# Function for ATM system
def atm():
    # Initial balance
    balance = 10000
    
    # Infinite loop until exit
    while True:
        # Take withdrawal amount
        amount = int(input("Enter amount to withdraw (0 to exit): "))
        
        # Exit condition
        if amount == 0:
            print("Exit")
            break
        
        # Check for invalid amount
        if amount < 0:
            print("Invalid amount")
        # Check insufficient balance
        elif amount > balance:
            print("Insufficient balance")
        else:
            # Deduct amount
            balance -= amount
            print("Withdrawal successful")
            print("Remaining balance:", balance)

# Call ATM function
atm()