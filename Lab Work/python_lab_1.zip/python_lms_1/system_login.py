# Function for login system
def login():
    # Store correct credentials
    correct_username = "admin"
    correct_password = "1234"
    
    # Initialize attempt counter
    attempts = 0
    
    # Allow maximum 3 attempts
    while attempts < 3:
        # Take username input
        username = input("Enter username: ")
        # Take password input
        password = input("Enter password: ")
        
        # Validate credentials
        if username == correct_username and password == correct_password:
            print("Login Successful")
            return
        else:
            print("Invalid credentials")
            # Increase attempt count
            attempts += 1
    
    # If all attempts fail
    print("Account Locked")

# Call login function
login()