# Function to print multiplication table
def table(n):
    # Check for negative input
    if n < 0:
        print("Negative number not allowed")
        return
    
    # Loop from 1 to 10
    for i in range(1, 11):
        # Print multiplication result
        print(n, "x", i, "=", n * i)

# Take input number
num = int(input("Enter number: "))

# Call function
table(num)