# Function to check palindrome
def is_palindrome(value):
    # Convert input to string
    value = str(value)
    
    # Initialize pointers
    start = 0
    end = len(value) - 1
    
    # Loop until pointers meet
    while start < end:
        # Compare characters
        if value[start] != value[end]:
            return False
        # Move pointers
        start += 1
        end -= 1
    
    # If all matched
    return True

# Take input
data = input("Enter number/string: ")

# Check and display result
if is_palindrome(data):
    print("Palindrome")
else:
    print("Not Palindrome")