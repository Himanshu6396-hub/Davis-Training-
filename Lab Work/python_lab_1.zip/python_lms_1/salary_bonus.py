# Function to calculate salary with bonus
def calculate_bonus(salary, years):
    # Check experience more than 10 years
    if years > 10:
        bonus = salary * 0.20
    # Check experience between 5 and 10
    elif years >= 5:
        bonus = salary * 0.10
    # Experience less than 5
    else:
        bonus = salary * 0.05
    
    # Return total salary
    return salary + bonus

# Loop for multiple employees
for i in range(3):
    # Take salary input
    salary = float(input("Enter salary: "))
    # Take experience input
    years = int(input("Enter experience: "))
    
    # Calculate total salary
    total = calculate_bonus(salary, years)
    
    # Display result
    print("Final Salary:", total)