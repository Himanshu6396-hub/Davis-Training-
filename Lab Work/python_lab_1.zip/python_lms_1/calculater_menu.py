# Function for calculator
def calculator():
    # Infinite loop for menu
    while True:
        # Display menu options
        print("\n1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Exit")
        
        # Take user choice
        choice = int(input("Enter choice: "))
        
        # Exit condition
        if choice == 5:
            print("Exiting...")
            break
        
        # Take two numbers
        a = float(input("Enter first number: "))
        b = float(input("Enter second number: "))
        
        # Perform operations
        if choice == 1:
            print("Result:", a + b)
        elif choice == 2:
            print("Result:", a - b)
        elif choice == 3:
            print("Result:", a * b)
        elif choice == 4:
            # Handle divide by zero
            if b == 0:
                print("Cannot divide by zero")
            else:
                print("Result:", a / b)
        else:
            print("Invalid choice")

# Call calculator function
calculator()