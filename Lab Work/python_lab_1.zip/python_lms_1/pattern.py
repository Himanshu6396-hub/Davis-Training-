# Take number of rows
rows = int(input("Enter number of rows: "))

# Loop for rows
for i in range(1, rows + 1):
    # Loop for columns
    for j in range(i):
        # Check if row is even
        if i % 2 == 0:
            print("*", end=" ")
        # If row is odd
        else:
            print("#", end=" ")
    # Move to next line
    print()