# Function to classify number
def classify_number(num):
    if num > 0:
        print(num, "is Positive")
    elif num < 0:
        print(num, "is Negative")
    else:
        print(num, "is Zero")
    
    # Nested if for even/odd check
    if num != 0:
        # Check if number is even
        if num % 2 == 0:
            print("Even")
        # Otherwise odd
        else:
            print("Odd")

# List of numbers
numbers = [10, -5, 0, 7, -2]

# Loop through all numbers
for num in numbers:
    # Call classification function
    classify_number(num)
    print("------")