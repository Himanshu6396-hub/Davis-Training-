# Function to check prime number
def is_primeNo(n):
    # Numbers <=1 are not prime
    if n <= 1:
        return False
    
    # Loop from 2 to n-1
    for i in range(2, n):
        # Check divisibility
        if n % i == 0:
            return False
    
    # If no divisor found
    return True

# Take input from user
num = int(input("Enter number: "))

# Check and display result
if is_primeNo(num):
    print("Prime Number")
else:
    print("Not a Prime Number")