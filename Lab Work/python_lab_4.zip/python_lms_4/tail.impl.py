n = int(input("Enter number of lines: "))  # user input

file = open("tail.txt", "r")
lines = file.readlines()   # read all lines

print("\nLast", n, "lines:\n")

for line in lines[-n:]:    # slice last n lines
    print(line.strip())

file.close()