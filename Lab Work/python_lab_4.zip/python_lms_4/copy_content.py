source = open("source.txt", "r")   # open source file in read mode
data = source.read()              # read full content

destination = open("destination.txt", "w")  # open destination file
destination.write(data)           # write content

source.close()                    # close source file
destination.close()               # close destination file

print("File copied successfully")