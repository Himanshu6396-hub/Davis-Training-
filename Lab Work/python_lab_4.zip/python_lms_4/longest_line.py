file = open("longest.txt", "r")   # file open

longest = ""                   # longest line store karne ke liye

for line in file:              # har line read karo
    if len(line) > len(longest):  # length compare karo
        longest = line         # update longest line

file.close()

print("Longest line:", longest.strip())  # line print
print("Length:", len(longest.strip()))  # length print