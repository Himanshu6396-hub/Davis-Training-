keyword = input("Enter keyword: ")

file = open("search.txt", "r")

for line in file:
    if keyword.lower() in line.lower():  # case insensitive search
        print(line.strip())

file.close()