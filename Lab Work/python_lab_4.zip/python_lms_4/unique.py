f1 = open("one_file.txt", "r")   # open first file
f2 = open("one1_file.txt", "r")   # open second file

lines2 = f2.readlines()       # store all lines of file2

print("Lines in file1 but not in file2:\n")

for line in f1:               # loop file1
    if line not in lines2:    # check difference
        print(line.strip())   # print unique lines

f1.close()
f2.close()