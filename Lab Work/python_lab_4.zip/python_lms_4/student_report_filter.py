file = open("students.txt", "r")     # open input file
out = open("top_students.txt", "w")  # output file

for line in file:                   # read line by line
    name, marks, city = line.strip().split(",")  # split data
    
    if int(marks) > 75:            # check condition
        out.write(line)            # write to new file

file.close()
out.close()

print("Filtered data saved")