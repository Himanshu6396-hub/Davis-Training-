import re

file = open("data.txt", "r")
text = file.read()

emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]+', text)

out = open("emails.txt", "w")

for e in emails:
    out.write(e + "\n")

file.close()
out.close()

print("Emails extracted")