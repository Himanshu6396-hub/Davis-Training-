import string

file = open("article.txt", "r")
text = file.read().lower()              # convert to lowercase

for p in string.punctuation:            # remove punctuation
    text = text.replace(p, "")

words = text.split()                    # split into words

freq = {}                               # dictionary

for w in words:
    if w in freq:
        freq[w] += 1
    else:
        freq[w] = 1

print(freq)

file.close()