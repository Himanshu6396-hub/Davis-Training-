file = open("input.txt", "r")
out = open("unique.txt", "w")

seen = set()                     # to track unique lines

for line in file:
    if line not in seen:        # check if not seen
        out.write(line)
        seen.add(line)          # add to set

file.close()
out.close()

print("Duplicates removed")