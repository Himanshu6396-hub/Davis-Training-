f1 = open("file1.txt", "r")
f2 = open("file2.txt", "r")
out = open("merged.txt", "w")

line_no = 1

for line in f1:
    out.write(str(line_no) + ". " + line)
    line_no += 1

for line in f2:
    out.write(str(line_no) + ". " + line)
    line_no += 1

f1.close()
f2.close()
out.close()

print("Files merged with line numbers")