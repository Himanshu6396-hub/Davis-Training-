file = open("input2.txt", "r")
lines = file.readlines()      # read all lines

out = open("reverse.txt", "w")

for line in reversed(lines):  # reverse lines
    out.write(line)

file.close()
out.close()

print("File reversed")