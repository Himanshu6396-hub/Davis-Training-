file = open("encpt.txt", "r")   # open file
text = file.read()

shift = 3                      # shift value
encrypted = ""

for ch in text:
    if ch.isalpha():           # check alphabet
        encrypted += chr(ord(ch) + shift)  # shift character
    else:
        encrypted += ch        # keep same

out = open("encrypted.txt", "w")  # output file
out.write(encrypted)

file.close()
out.close()

print("Encrypted successfully")