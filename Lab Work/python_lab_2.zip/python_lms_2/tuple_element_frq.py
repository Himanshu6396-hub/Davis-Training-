t = tuple(map(int, input("Enter tuple elements: ").split()))  # input tuple

freq = {}  # dictionary

for i in t:  # loop
    if i in freq:
        freq[i] += 1
    else:
        freq[i] = 1

print(freq)  # output