t = tuple(map(int, input("Enter tuple: ").split()))  # input tuple
target = int(input("Enter sum: "))  # target sum

pairs = []  # list

for i in range(len(t)):
    for j in range(i+1, len(t)):
        if t[i] + t[j] == target:
            pairs.append((t[i], t[j]))

print(pairs)  # output