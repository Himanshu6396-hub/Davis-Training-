n = int(input("Enter number of sublists: "))  # number of sublists

nested = []

for i in range(n):
    sub = list(map(int, input("Enter sublist: ").split()))
    nested.append(sub)

flat = []

for sub in nested:
    for i in sub:
        flat.append(i)

print(flat)