lst = list(map(int, input("Enter elements: ").split()))  # input list
k = int(input("Enter k: "))  # input rotation count

k = k % len(lst)  # handle large k
rotated = lst[-k:] + lst[:-k]  # rotate

print(rotated)  # output