lst = list(map(int, input("Enter elements: ").split()))  # input list

unique = []  # list for unique

for i in lst:  # loop
    if i not in unique:
        unique.append(i)

result = tuple(unique)  # convert to tuple

print(result)  # output