l1 = list(map(int, input("Enter list1: ").split()))  # input list1
l2 = list(map(int, input("Enter list2: ").split()))  # input list2

merged = list(set(l1 + l2))  # merge + remove duplicates
merged.sort()  # sort

print(merged)  # output