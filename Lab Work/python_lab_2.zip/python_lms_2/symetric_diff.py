set1 = set(map(int, input("Enter set1: ").split()))
set2 = set(map(int, input("Enter set2: ").split()))

result = set1 ^ set2  # symmetric difference

print(result)