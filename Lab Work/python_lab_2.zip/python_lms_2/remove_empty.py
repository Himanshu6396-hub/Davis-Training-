n = int(input("Enter number of sets: "))  # number of sets

lst = []  # list of sets

for i in range(n):
    s = input("Enter elements (blank for empty): ")  # input
    if s == "":
        lst.append(set())  # empty set
    else:
        lst.append(set(map(int, s.split())))  # normal set

result = []  # result list

for i in lst:
    if i:  # check non-empty
        result.append(i)

print(result)  # output