set1 = set(map(int, input("Enter set1: ").split()))  # input set1
set2 = set(map(int, input("Enter set2: ").split()))  # input set2

print(set1.issubset(set2))  # check subset