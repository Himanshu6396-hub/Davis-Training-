list1 = list(map(int, input("Enter list1: ").split()))  # input list1
list2 = list(map(int, input("Enter list2: ").split()))  # input list2

result = []  # empty list

for i in list1:  # loop
    if i not in list2:  # check condition
        result.append(i)

print(result)  # output