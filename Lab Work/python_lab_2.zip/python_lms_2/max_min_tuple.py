t = tuple(map(int, input("Enter tuple elements: ").split()))  # input tuple

max_val = t[0]  # assume first element
min_val = t[0]

for i in t:  # loop
    if i > max_val:
        max_val = i
    if i < min_val:
        min_val = i

print("Max =", max_val)
print("Min =", min_val)