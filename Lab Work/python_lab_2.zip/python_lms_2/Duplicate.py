lst = [1, 2, 3, 2, 4, 5, 1]   # input list
duplicates = []              # empty list to store duplicates

for i in lst:                # loop through each element
    if lst.count(i) > 1 and i not in duplicates:  # check if element appears more than once
        duplicates.append(i) # add to duplicates list

print(duplicates)            # print result