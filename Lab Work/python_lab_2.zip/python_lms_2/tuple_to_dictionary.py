keys = tuple(input("Enter keys: ").split())  # input keys
values = tuple(map(int, input("Enter values: ").split()))  # input values

result = {}

for i in range(len(keys)):
    result[keys[i]] = values[i]

print(result)