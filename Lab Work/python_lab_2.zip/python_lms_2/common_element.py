l1 = list(map(int, input("Enter list1: ").split()))
l2 = list(map(int, input("Enter list2: ").split()))
l3 = list(map(int, input("Enter list3: ").split()))

result = []

for i in l1:
    if i in l2 and i in l3:
        result.append(i)

print(result)