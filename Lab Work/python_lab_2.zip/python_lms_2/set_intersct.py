set1 = set(map(int, input("Enter set1: ").split()))  # input set1
set2 = set(map(int, input("Enter set2: ").split()))  # input set2

intersection = set1 & set2  # intersection
difference = set1 - set2    # difference

print("Intersection:", intersection)
print("Difference:", difference)