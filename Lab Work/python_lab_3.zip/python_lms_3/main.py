import geometry  # import module

while True:
    print("\n----- SELECT SHAPE -----")
    print("1. Cube")
    print("2. Cuboid")
    print("3. Cylinder")
    print("4. Cone")
    print("5. Sphere")
    print("6. Exit")

    choice = int(input("Enter choice: "))

    if choice == 6:
        break

    print("\n--- SELECT OPERATION ---")
    print("1. Curved Surface Area")
    print("2. Total Surface Area")
    print("3. Volume")

    op = int(input("Enter operation: "))

    # -------- CUBE --------
    if choice == 1:
        a = float(input("Enter side: "))

        if op == 1:
            print("CSA =", geometry.cube_csa(a))
        elif op == 2:
            print("TSA =", geometry.cube_tsa(a))
        elif op == 3:
            print("Volume =", geometry.cube_volume(a))

    # -------- CUBOID --------
    elif choice == 2:
        l = float(input("Enter length: "))
        b = float(input("Enter breadth: "))
        h = float(input("Enter height: "))

        if op == 1:
            print("CSA =", geometry.cuboid_csa(l, b, h))
        elif op == 2:
            print("TSA =", geometry.cuboid_tsa(l, b, h))
        elif op == 3:
            print("Volume =", geometry.cuboid_volume(l, b, h))

    # -------- CYLINDER --------
    elif choice == 3:
        r = float(input("Enter radius: "))
        h = float(input("Enter height: "))

        if op == 1:
            print("CSA =", geometry.cylinder_csa(r, h))
        elif op == 2:
            print("TSA =", geometry.cylinder_tsa(r, h))
        elif op == 3:
            print("Volume =", geometry.cylinder_volume(r, h))

    # -------- CONE --------
    elif choice == 4:
        r = float(input("Enter radius: "))
        h = float(input("Enter height: "))
        l = float(input("Enter slant height: "))

        if op == 1:
            print("CSA =", geometry.cone_csa(r, l))
        elif op == 2:
            print("TSA =", geometry.cone_tsa(r, l))
        elif op == 3:
            print("Volume =", geometry.cone_volume(r, h))

    # -------- SPHERE --------
    elif choice == 5:
        r = float(input("Enter radius: "))

        if op == 1 or op == 2:
            print("Surface Area =", geometry.sphere_tsa(r))
        elif op == 3:
            print("Volume =", geometry.sphere_volume(r))

    else:
        print("Invalid choice")