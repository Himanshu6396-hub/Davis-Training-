import math  # for pi

# ------------------ CUBE ------------------
def cube_csa(a):  # curved surface area
    return 4 * a * a

def cube_tsa(a):  # total surface area
    return 6 * a * a

def cube_volume(a):  # volume
    return a ** 3


# ------------------ CUBOID ------------------
def cuboid_csa(l, b, h):
    return 2 * h * (l + b)

def cuboid_tsa(l, b, h):
    return 2 * (l*b + b*h + h*l)

def cuboid_volume(l, b, h):
    return l * b * h


# ------------------ CYLINDER ------------------
def cylinder_csa(r, h):
    return 2 * math.pi * r * h

def cylinder_tsa(r, h):
    return 2 * math.pi * r * (r + h)

def cylinder_volume(r, h):
    return math.pi * r * r * h


# ------------------ CONE ------------------
def cone_csa(r, l):
    return math.pi * r * l

def cone_tsa(r, l):
    return math.pi * r * (r + l)

def cone_volume(r, h):
    return (1/3) * math.pi * r * r * h


# ------------------ SPHERE ------------------
def sphere_csa(r):
    return 4 * math.pi * r * r

def sphere_tsa(r):
    return 4 * math.pi * r * r

def sphere_volume(r):
    return (4/3) * math.pi * r ** 3


# ------------------ HEMISPHERE ------------------
def hemi_csa(r):
    return 2 * math.pi * r * r

def hemi_tsa(r):
    return 3 * math.pi * r * r

def hemi_volume(r):
    return (2/3) * math.pi * r ** 3